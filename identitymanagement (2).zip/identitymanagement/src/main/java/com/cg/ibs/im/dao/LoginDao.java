package com.cg.ibs.im.dao;

public interface LoginDao {
	
	 long verifyUser(String username);
}
