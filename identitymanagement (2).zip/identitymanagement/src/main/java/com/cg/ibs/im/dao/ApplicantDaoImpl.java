package com.cg.ibs.im.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.cg.ibs.bean.ApplicantBean;
import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;
import com.cg.ibs.im.exception.IBSCustomException;

public class ApplicantDaoImpl implements ApplicantDao {

	private Map<Long, ApplicantBean> applicantDao = new HashMap<Long, ApplicantBean>();
	private ApplicantBean applicant;

	@Override
	public boolean saveApplicant(ApplicantBean applicant) {
		boolean result = false;
		if (applicant != null) { // check if applicant already exists. (out of
									// scope)
			applicantDao.put(applicant.getApplicantId(), applicant);
			result = true;
		}
		return result;
	}

	@Override
	public Set<Long> getAllApplicants() {
		return new TreeSet<Long>(applicantDao.keySet());

	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantId) throws IBSCustomException {
		ApplicantBean newApplicant = null;
		for (Map.Entry<Long, ApplicantBean> entry : applicantDao.entrySet()) {
			if (entry.getKey().equals(applicantId)) {
				newApplicant = entry.getValue();
				break;
			}
		}
		if(newApplicant==null){
			throw new IBSCustomException("Application not found.");
		}
		return newApplicant;
	}

	@Override
	public Set<Long> getApplicantsByStatus(ApplicantStatus applicantStatus) {
		
		Set<Long> applicants = new TreeSet<Long>();
		for (Map.Entry<Long, ApplicantBean> entry : applicantDao.entrySet()) {
			applicant=entry.getValue();
			if(applicant.getApplicantStatus()==applicantStatus){
				applicants.add(applicant.getApplicantId());
			}
		}
		return applicants;
	}

}
