package com.cg.ibs.im.service;

import java.util.List;

import com.cg.ibs.bean.ApplicantBean;

public class BankerSeviceImpl implements BankerService {

	@Override
	public boolean verifyLogin(String user, String password) {
		return true;
	}

	@Override
	public List<Long> viewPendingApplications() {
		return null;
	}

	@Override
	public List<Long> viewApprovedApplications() {
		return null;
	}

	@Override
	public List<Long> viewDeniedApplications() {
		return null;
	}

	@Override
	public boolean updateStatus(long applicantId) {
		return false;
	}

	@Override
	public ApplicantBean displayDetails(long applicantId) {
		return null;
	}
	
}
