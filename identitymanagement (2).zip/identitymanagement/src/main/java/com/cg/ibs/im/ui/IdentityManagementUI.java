package com.cg.ibs.im.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.ibs.bean.ApplicantBean;
import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;
import com.cg.ibs.im.service.BankerSeviceImpl;
import com.cg.ibs.im.service.CustomerServiceImpl;

public class IdentityManagementUI {
	static Scanner scanner;
	
	
	public CustomerServiceImpl customer = new CustomerServiceImpl();
	public BankerSeviceImpl banker = new BankerSeviceImpl();

	void init() {
		UserMenu choice = null;
		while (UserMenu.QUIT != choice) {
			System.out.println("------------------------");
			System.out.println("Choose your identity from MENU:");
			System.out.println("------------------------");
			for (UserMenu menu : UserMenu.values()) {
				System.out.println(menu.ordinal() + "\t" + menu);
			}
			System.out.println("Choice");
			int ordinal = scanner.nextInt();
			
			if(0<=ordinal && UserMenu.values().length>ordinal){
				choice = UserMenu.values()[ordinal];
				switch(choice){
				case BANKER:
					selectBankerAction();
					break;
				case CUSTOMER:
					selectCustomerAction();
					break;
				case SERVICE_PROVIDER:
					selectSPAction();
					break;
				case QUIT:
					System.out.println("Application closed!!");
					break;
				} 
			} else {
				System.out.println("Please enter a valid option.");
				choice=null;
			}
			
		}

	}
	
	public void selectBankerAction(){
		if(bankerLogin()){
			BankerAction choice = null;
			System.out.println("------------------------");
			System.out.println("Choose a valid option");
			System.out.println("------------------------");
			for (BankerAction menu : BankerAction.values()) {
				System.out.println(menu.ordinal()  + "\t" + menu);
			}
			System.out.println("Choices:");
			int ordinal = scanner.nextInt();
			
			if(0<=ordinal && BankerAction.values().length>ordinal){
				choice = BankerAction.values()[ordinal];
				switch(choice){
				case VIEW_PENDING_DETAILS:
					pendingApplications();
					break;
				case VIEW_APPROVED_DETAILS:
					approvedApplications();
					break;
				case VIEW_DENIED_DETAILS:
					deniedApplications();
					break;
				case QUIT:
					System.out.println("BACK ON HOME PAGE!!");
					break;
				} 
			} else {
				System.out.println("Please enter a valid option.");
				choice=null;
			}
		}
	}
	
	public void selectCustomerAction(){
		CustomerMenu choice=null;
		System.out.println("------------------------");
		System.out.println("Choose an appropriate option from MENU:");
		System.out.println("------------------------");
		for (CustomerMenu menu : CustomerMenu.values()) {
			System.out.println(menu.ordinal() + "\t" + menu);
		}
		System.out.println("Choice");
		int ordinal = scanner.nextInt();
		
		if(0<=ordinal && UserMenu.values().length>ordinal){
			choice = CustomerMenu.values()[ordinal];
			switch(choice){
			case SIGNUP:
				signUp();
				break;
			case LOGIN:
				login();
				break;
			case CHECK_STATUS:
				checkStatus();
				break;
			case QUIT:
				System.out.println("Application closed!!");
				break;
			} 
		} else {
			System.out.println("Please enter a valid option.");
			choice=null;
		}
		
	}
	
	public void selectSPAction(){
		System.out.println("Out of Scope!!!!!!!!!");			//LATER~~
	}
	
	void pendingApplications(){
		List<Long> pendingList = banker.viewPendingApplications();
		if(pendingList.size()>0){
			//View Pending Applications
			//Iterate List here
		} else {
			System.out.println("There are no pending applicant requests.");
		}
		
		System.out.println("Enter an application number to check details:");
		long applicantId = scanner.nextLong();
		banker.displayDetails(applicantId);
		
		String confirmation = "no";
//		while(confirmation.toLowerCase()=="no"){
//			System.out.println("------------------------");
//			System.out.println("Choose valid option:");
//			System.out.println("------------------------");
//			System.out.println("1.\tApprove application");
//			System.out.println("2.\tDeny application");
//			int choice = scanner.nextInt();
//			System.out.println("Are you sure?\n1. yes\n2.no");
//			confirmation= scanner.next();
//			if(confirmation.toLowerCase()=="yes"){
//				banker.updateStatus(applicantId)
//			}
//			confirmation = confirmation.toLowerCase();
//		}
	}

	void approvedApplications(){
		List<Long> approvedList = banker.viewApprovedApplications();
		if(approvedList.size()>0){
			//View Approved Applications
			//Iterate List here
		} else {
			System.out.println("There are no approved applications.");
		}
	}
	
	void deniedApplications(){
		List<Long> deniedList = banker.viewDeniedApplications();
		if(deniedList.size()>0){
			//View Denied Applications
			//Iterate List here
		} else {
			System.out.println("There are no denied applications.");
		}
	}
	
	public void signUp() {
		System.out.println("Do you want to open an individual account or Joint account?");
		//Functions for individual/joint account
		//Set account type
		
		ApplicantBean applicant = new ApplicantBean();
		
		System.out.println("Enter the following Details:");
		System.out.println("Enter the first name");
		applicant.setFirstName(scanner.next());
		
		System.out.println("Enter the last name");
		applicant.setLastName(scanner.next());
		
		System.out.println("Enter Father's name");
		applicant.setFatherName(scanner.next());
		
		System.out.println("Enter Mother's name");
		applicant.setMotherName(scanner.next());
		
		System.out.println("Enter your Date of Birth");
		DateTimeFormatter dtFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String dob= scanner.next();
		LocalDate dob= LocalDate.parse(dob, dtFormat);
		System.out.println(dtFormat.format(dob));
		
		//Enter Gender
		
		//Permanent Address
		
		//Current Address
		
		System.out.println("Enter Mobile number");
		applicant.setMobileNumber(scanner.next());
		
		System.out.println("Enter Alternate Mobile Number");
		applicant.setAlternateMobileNumber(scanner.next());
		
		System.out.println("Enter email id");
		applicant.setEmailId(scanner.next());
		
		System.out.println("Enter Aadhar Number");
		applicant.setAadharNumber(scanner.next());
		
		System.out.println("Enter Pan Number");
		applicant.setPanNumber(scanner.next());
		
		System.out.println("Submit application?");
		//yes, no
		
		
		
	}
	
	public void login(){
		
		System.out.println("Please enter the username");  //Login using UCI later
		String user = scanner.next();
		System.out.println("Enter the password");
		String password = scanner.next();
		if(customer.login(user, password)){
			System.out.println("Welcome to the Home Page!!");
		} else {
			System.out.println("INVALID DETAILS! Enter the details again.");
			login();
		}
	}
	
	public void checkStatus(){
		System.out.println("Enter the applicant ID to check status:");
		long applicantId = scanner.nextLong();
		while(!customer.verifyApplicantId(applicantId)){
			System.out.println("Please enter a valid applicant ID");
			applicantId= scanner.nextLong();
		}
		ApplicantStatus status = customer.checkStatus(applicantId);
		System.out.println("Your application status is: "+ status);
		
	}
	
	public boolean bankerLogin(){
		System.out.println("Enter a login ID:");
		String bankUser = scanner.next();
		System.out.println("Enter password:");
		String bankPassword = scanner.next();
		if(!banker.verifyLogin(bankUser, bankPassword)){
			System.out.println("Please enter valid details");
			bankerLogin();
		}
		return true;
	}

	public static void main(String[] args) {

		scanner = new Scanner(System.in);
		IdentityManagementUI identityManagement = new IdentityManagementUI();
		identityManagement.init();
		scanner.close();

	}
}
