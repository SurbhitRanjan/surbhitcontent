package com.cg.ibs.im.dao;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import com.cg.ibs.bean.IBSUser;
import com.cg.ibs.bean.IBSUser.Role;

public class LoginDaoImpl implements LoginDao {
	
	private static Map<BigInteger, IBSUser> loginDao = new HashMap<BigInteger, IBSUser>();
	
	static{
		IBSUser user1= new IBSUser();
		user1.setUid(new BigInteger("12345678"));
		user1.setUsername("admin1");
		user1.setPassword("12345");
		user1.setRole(Role.ADMIN);
		loginDao.put(user1.getUid(), user1);
		
		IBSUser user2= new IBSUser();
		user2.setUid(new BigInteger("12345679"));
		user2.setUsername("admin2");
		user2.setPassword("qwerty");
		user2.setRole(Role.ADMIN);
		loginDao.put(user2.getUid(), user2);
	}
	

	@Override
	public long verifyUser(String username) {
		// TODO Auto-generated method stub
		
		
		return 0;
	}

	
	
	
	
}
