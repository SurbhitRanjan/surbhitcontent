package com.cg.ibs.ui;

public enum CustomerMenu {
	SIGNUP, LOGIN, CHECK_STATUS, QUIT
}
