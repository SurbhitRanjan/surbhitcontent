package com.cg.ibs.ui;

public enum UserMenu {
	BANKER, CUSTOMER, SERVICE_PROVIDER, QUIT
}


