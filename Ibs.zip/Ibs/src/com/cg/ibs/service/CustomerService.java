package com.cg.ibs.service;

import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;

public interface CustomerService {
	
	boolean verifyApplicantId(long applicantId);
	
	ApplicantStatus checkStatus(long applicantId);
	
	boolean login(String username, String password);
}
