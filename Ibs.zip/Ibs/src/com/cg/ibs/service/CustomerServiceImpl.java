package com.cg.ibs.service;

import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;

public class CustomerServiceImpl implements CustomerService{

	@Override
	public boolean verifyApplicantId(long applicantId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ApplicantStatus checkStatus(long applicantId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
