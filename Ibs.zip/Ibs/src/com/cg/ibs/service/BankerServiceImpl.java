package com.cg.ibs.service;

import java.util.List;
import java.util.Set;

import com.cg.ibs.bean.ApplicantBean;
import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;
import com.cg.ibs.dao.ApplicantDaoImpl;
import com.cg.ibs.im.exception.IBSCustomException;

public class BankerServiceImpl implements BankerService {

	@Override
	public boolean verifyLogin(String user, String password) {
		return true;
	}

	@Override
	public List<Long> viewPendingApplications() {
		ApplicantDaoImpl applicantDao = new ApplicantDaoImpl();
		Set pendingList = applicantDao.getApplicantsByStatus(ApplicantStatus.PENDING);
		
		
		return (List<Long>) pendingList;
	}

	@Override
	public List<Long> viewApprovedApplications() {
		ApplicantDaoImpl applicantDao = new ApplicantDaoImpl();
	    Set approvedList = applicantDao.getApplicantsByStatus(ApplicantStatus.APPROVED);
	    
	
	    return (List<Long>) approvedList;
	 }

	@Override
	public List<Long> viewDeniedApplications() {
		ApplicantDaoImpl applicantDao = new ApplicantDaoImpl();
	    Set deniedList = applicantDao.getApplicantsByStatus(ApplicantStatus.DENIED);
	 
	
	
	    return (List<Long>) deniedList;
	  }

	@Override
	public boolean updateStatus(long applicantId) {
		
		ApplicantDaoImpl applicantDao = new ApplicantDaoImpl();
		
			if(applicantDao == null)
			{
				throw IBSCustomException ("Not found");
				
			}
			else
				
		
		return false;
	}

	
	//public ApplicantBean displayDetails(long applicantId) {
		//return null;
	
	
}
