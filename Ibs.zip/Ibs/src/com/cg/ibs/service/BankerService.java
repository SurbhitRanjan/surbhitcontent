package com.cg.ibs.service;

import java.util.List;

import com.cg.ibs.bean.ApplicantBean;

public interface BankerService {
	boolean verifyLogin(String user, String password);
	
	List<Long> viewPendingApplications();
	
	List<Long> viewApprovedApplications();
	
	List<Long> viewDeniedApplications();
	
	ApplicantBean displayDetails(long applicantId);
	
	boolean updateStatus(long applicantId);
	
}
