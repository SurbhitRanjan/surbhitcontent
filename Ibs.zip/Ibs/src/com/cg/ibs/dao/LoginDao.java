package com.cg.ibs.dao;

public interface LoginDao {
	
	 long verifyUser(String username);
}
