package com.cg.ibs.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.ibs.bean.CustomerBean;

public class CustomerDaoImpl implements CustomerDao{
	
	private Map<String, CustomerBean> customerDao = new HashMap<String, CustomerBean>();

	@Override
	public boolean saveCustomer() {
		boolean result = false;
		
		return result;
	}

	@Override
	public CustomerBean getCustomerDetails(String uci) {
		return null;
	}

	@Override
	public List<String> getAllCustomers() {
		return null;
	}
	
}
