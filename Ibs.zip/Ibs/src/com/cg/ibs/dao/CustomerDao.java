package com.cg.ibs.dao;

import java.util.List;

import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;
import com.cg.ibs.bean.CustomerBean;

public interface CustomerDao {
	
	
	boolean saveCustomer();
	
	CustomerBean getCustomerDetails(String uci);
	
	List<String> getAllCustomers();
	
	
}
